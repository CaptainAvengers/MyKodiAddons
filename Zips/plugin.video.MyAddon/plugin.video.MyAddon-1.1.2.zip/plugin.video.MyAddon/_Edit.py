import xbmcaddon


MainBase = 'https://goo.gl/Umeiax '
addon = xbmcaddon.Addon('plugin.video.MyAddon')