# plugin.video.dramacool
A video add-on for kodi that let you stream content from dramacool with english subtitles.

## Contains
- Drama
  - Korean Drama
  - Japanese Drama
  - Taiwanese Drama
  - Hong Kong Drama
  - Chinese Drama
  - Other Asia Drama
  - Thailand Drama

- Drama Movie
  - Korean Movies
  - Japanese Movies
  - Taiwanese Movies
  - Hong Kong Movies
  - Chinese Movies
  - American Movies
  - Other Asia Movies
  - Thailand Movies

- Korean Show