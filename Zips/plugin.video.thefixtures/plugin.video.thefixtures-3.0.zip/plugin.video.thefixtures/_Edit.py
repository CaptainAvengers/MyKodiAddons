import xbmcaddon

MainBase = 'http://ask4access.com/fixturesapp/HOME/home.txt'
addon = xbmcaddon.Addon('plugin.video.thefixtures')