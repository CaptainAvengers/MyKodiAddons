import xbmcaddon

MainBase = 'http://bit.do/boom-menu'
addon = xbmcaddon.Addon('plugin.video.thefixtures')