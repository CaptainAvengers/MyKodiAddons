import xbmcaddon

MainBase = 'http://burrtv.tech/BOOM/Sport/home.xml'
addon = xbmcaddon.Addon('plugin.video.boom')