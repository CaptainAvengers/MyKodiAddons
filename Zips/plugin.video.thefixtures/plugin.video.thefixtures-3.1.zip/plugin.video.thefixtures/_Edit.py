import xbmcaddon

MainBase = 'http://ask4access.com/fixturesapp/HOME_21-09/home.txt'
addon = xbmcaddon.Addon('plugin.video.thefixtures')