import xbmcaddon

MainBase = 'http://ask4access.com/fixturesapp/HOME_27-10/home.txt'
addon = xbmcaddon.Addon('plugin.video.thefixtures')