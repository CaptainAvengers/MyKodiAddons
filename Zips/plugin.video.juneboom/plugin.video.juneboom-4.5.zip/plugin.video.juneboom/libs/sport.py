# dicts created in scraper
#     sportList.append({'adjTime':adjTime,'EvName':EvName,'EvLeague':EvLeague,'EvLink':EvLink,'EvIcon':EvIcon,'fanart':fanart})
#     racingList.append({'adjTime':adjTime,'EvName':EvName,'EvLeague':EvLeague,'EvLink':EvLink,'EvIcon':EvIcon,'fanart':fanart})

# xml format used
#    f2.write ('<item>'+'\n')
#    f2.write ('\t'+'<title>[COLOR red]'+adjTime+' - [COLOR white]'+EvName+'[COLOR FFff8397b0][I] ('+EvLeague+')[/I][/COLOR]</title>'+'\n')
#    f2.write ('\t'+'<link>'+EvLink+'</link>'+'\n')
#    f2.write ('\t'+'<thumbnail>'+EvIcon+'</thumbnail>'+'\n')
#    f2.write ('\t'+'<fanart>'+fanart+'</fanart>'+'\n')
#    f2.write ('</item>'+'\n')
#    f2.write ('\n')

import byb_modules as BYB
from ._addon import *
from ._common import *

def index():
	#   BYB.addDir(HesGoal(local_string(30082)),url,1101,iconimage,fanart,'','','','')
	BYB.addDir(ChannelColor('HesGoal Events'),'',9001,addon_icon ,addon_fanart,'','','','')

def HesGoal():
    sportList =[]
    racingList = []
    from .scrapers import hesgoal
    hesgoal.scrapeContent()
    print 'BACK in sport py '
    print '\n'+'sportList - '+str (sportList)                  
    print '\n'+'racingList - '+str (racingList)      
    
    for items in hesgoal.sportList: 
        adjTime =items.get('adjTime','Time Missing')
        EvName =items.get('EvName','Title Missing')
        EvLeague =items.get('EvLeague','League Missing')
        EvLink =items.get('EvLink','Link Missing')
        EvIcon =items.get('EvIcon','Icon Missing')
        evFanart =items.get('fanart','Fanart Missing')
        if EvName == 'Main Sports Events':
            title = '[COLOR gold]'+EvName+'[/COLOR]'
            icon = 'https://i.imgur.com/FZ1wlg4.png'
        else:
            title = '[COLOR red]'+adjTime+' - [COLOR white]'+EvName+'[COLOR FFff8397b0][I] ('+EvLeague+')[/I][/COLOR]'
            icon = EvIcon
		
        fanart = evFanart
        url = EvLink
        BYB.addDir_file(ChannelColor(title),url,9002,icon,fanart,'Hes-Goal Sports Events','','','')
		
    for items in hesgoal.racingList: 
        adjTime =items.get('adjTime','Time Missing')
        EvName =items.get('EvName','Title Missing')
        EvLeague =items.get('EvLeague','League Missing')
        EvLink =items.get('EvLink','Link Missing')
        EvIcon =items.get('EvIcon','Icon Missing')
        evFanart =items.get('fanart','Fanart Missing')
        if EvName == 'Racing Events':
            title = '[COLOR gold]'+EvName+'[/COLOR]'
            icon = 'https://i.imgur.com/FZ1wlg4.png'
        else:
            title = '[COLOR red]'+adjTime+' - [COLOR white]'+EvName+'[COLOR FFff8397b0][I] ('+EvLeague+')[/I][/COLOR]'
            icon = EvIcon
		
        fanart = evFanart
        url = EvLink
        BYB.addDir_file(ChannelColor(title),url,9002,icon,fanart,'Hes-Goal Racing Events','','','')
		

